
{-# LANGUAGE DataKinds, GADTs, TypeFamilies, TypeOperators, MultiParamTypeClasses, ConstraintKinds, ScopedTypeVariables, UndecidableInstances, FlexibleContexts, FlexibleInstances, StandaloneDeriving, TypeApplications, IncoherentInstances#-} 
{-# OPTIONS_GHC -fplugin GHC.TypeLits.Normalise #-}
{-# LANGUAGE InstanceSigs #-}

module FixedVector where

import GHC.TypeNats
import qualified Data.Vector as V 
import Data.Proxy
import Data.Finite


data Vec (n::Nat) a = UnsafeMkVec {getVector :: V.Vector a}

mkVec :: forall n a. KnownNat n => V.Vector a -> Maybe (Vec n a)
mkVec v | V.length v == l = Just (UnsafeMkVec v)
        | otherwise = Nothing
    where l = fromIntegral (natVal (Proxy @n))

instance Functor (Vec n) where
    fmap :: (a -> b) -> Vec n a -> Vec n b
    fmap f v = UnsafeMkVec $ V.map f (getVector v)

(++) :: Vec n a -> Vec m a -> Vec (m+n) a
(++) (UnsafeMkVec xs) (UnsafeMkVec ys) = UnsafeMkVec (xs V.++ ys)

zipVec :: Vec n a -> Vec n b -> Vec n (a, b)
zipVec (UnsafeMkVec xs) (UnsafeMkVec ys) = UnsafeMkVec (V.zip xs ys)

takeVec :: forall n m a. KnownNat n =>  Vec (n+m) a -> Vec n a
takeVec (UnsafeMkVec xs) = UnsafeMkVec (V.take l xs) where
    l = fromIntegral $ natVal $ Proxy @n

splitVec :: forall n m a. KnownNat n => Vec (n+m) a -> (Vec n a, Vec m a)
splitVec (UnsafeMkVec xs) = (UnsafeMkVec ys, UnsafeMkVec zs) where
    l = fromIntegral $ natVal $ Proxy @n
    (ys, zs) = V.splitAt l xs

