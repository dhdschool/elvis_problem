
{-# LANGUAGE DataKinds, GADTs, TypeFamilies, TypeOperators, MultiParamTypeClasses, ConstraintKinds, ScopedTypeVariables, UndecidableInstances, FlexibleContexts, FlexibleInstances, StandaloneDeriving, IncoherentInstances#-} 
{-# OPTIONS_GHC -fplugin GHC.TypeLits.Normalise #-}

module Grad where
import qualified Data.Kind



