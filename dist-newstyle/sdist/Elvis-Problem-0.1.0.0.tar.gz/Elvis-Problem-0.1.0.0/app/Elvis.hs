
{-# LANGUAGE DataKinds, GADTs, TypeFamilies, TypeOperators, MultiParamTypeClasses, ConstraintKinds, ScopedTypeVariables, UndecidableInstances, FlexibleContexts, FlexibleInstances, StandaloneDeriving, IncoherentInstances#-} 
{-# OPTIONS_GHC -fplugin GHC.TypeLits.Normalise #-}
module Elvis where

import FixedVector
import qualified Data.Kind
import Data.Data (Data)

precision :: Num a => a
precision = 8

identityMat :: (RealFloat a) => Vec n a -> Vec n (Vec n a)
zeroVecs :: (RealFloat a) =>  Vec n a -> Vec n a


zeroVecs Nil = Nil
zeroVecs (x:#xs) = 0 :# zeroVecs xs



-- baseVecs Nil = Nil
-- baseVecs (x:#xs) = (1 :# zeroVecs xs)
class Jacobian m
instance (RealVec v a) => Jacobian (Vec m (v a))

class (RealFloat a, Foldable v, Applicative v) => RealVec v a where    
    norm :: v a -> a 
    norm v = sqrt $ sum $ (**2) <$> v

    (<.>) :: v a -> v a -> a
    (<.>) x y = sum $ ((*) <$> x) <*> y

    (|+|) :: v a -> v a -> v a
    (|+|) x y = ((+) <$> x) <*> y 

    (|-|) :: v a -> v a -> v a
    (|-|) x y = ((-) <$> x) <*> y

    (|*|) :: a -> v a -> v a
    (|*|) r x = (r*) <$> x 

    dirDerivative :: (v a -> a) -> v a -> v a -> a
    dirDerivative f x v = (f(x |+| (h|*|v)) - f(x)) / h  where
        h = 10 ** (-precision)

    grad :: (v a -> a) -> v a -> v a

instance (RealFloat a) => RealVec (Vec 0) a where
    norm Nil = 0
    (<.>) Nil Nil = 0
    (|+|) Nil Nil = Nil
    (|*|) r Nil = Nil
    dirDerivative _ Nil Nil = 0
    grad _ Nil = Nil

instance forall n a. (RealFloat a, RealVec(Vec (n-1)) a, n>0) => RealVec (Vec n) a where
    --grad f x = dirDerivative f x <> 

class CSet s where
    contains :: (RealVec v a) => v a -> s (v a) -> Bool
    intersection :: (RealVec v a) => s (v a)-> s (v a) -> s (v a)
    add :: (RealVec v a) => s (v a) -> s (v a) -> s (v a)
    distance :: (RealVec v a) => v a -> s (v a) -> a

data VSet :: Nat -> Data.Kind.Type -> Data.Kind.Type where
    Empty :: (RealVec v a) => VSet 0 (v a)
    Set ::(RealVec v a) => [(v a  -> a)] -> VSet m (v a)

instance CSet (VSet 0) where
    contains :: RealVec v a => v a -> VSet 0 (v a) -> Bool
    contains v _ = False

    intersection :: RealVec v a => VSet 0 (v a) -> VSet 0 (v a) -> VSet 0 (v a)
    intersection _ _ = Empty

    add :: RealVec v a => VSet 0 (v a) -> VSet 0 (v a) -> VSet 0 (v a)
    add _ _ = Empty

    distance :: RealVec v a => v a -> VSet 0 (v a) -> a
    distance _ _ = 0


instance forall n. (CSet (VSet (n-1)), n>0) => CSet (VSet n) where
    contains v (Set f) = foldr (&&) True ((<=0) <$> (f <*> pure v))
    
    intersection (Set f1) (Set f2) = (Set $ f1 ++ f2)
    
    -- distance v s1
    --     | contains v s1 = 0
    --     | otherwise 
    

